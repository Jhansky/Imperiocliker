Imperio Clicker Android project.

Build APK with:
gradle assembleDebug

Output:
app/build/outputs/apk/debug/app-debug.apk
