# Imperio Clicker para Android

Este es un proyecto Android Studio que empaqueta el juego HTML como aplicación Android mediante WebView.

## Crear el APK
1. Descomprime `ImperioClickerAndroid.zip`.
2. Abre la carpeta `ImperioClickerAndroid` en Android Studio.
3. Espera a que Gradle termine de sincronizar.
4. Si Android Studio solicita instalar Android SDK 35 o herramientas de compilación, acepta.
5. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. El APK de prueba se generará en `app/build/outputs/apk/debug/app-debug.apk`.

La aplicación funciona sin internet y el juego conserva su guardado local en el almacenamiento del WebView.
